#include "calc.hpp"

int soma(int a, int b){
    return a+b;
}

int sub(int a, int b){
    return a-b;
}

int mult(int a, int b){
    return a*b;
}

float div(int a, int b){
    return a/b;
}
