#include "calc.hpp"
#include <iostream>

using namespace std;

int main(){

    int resultado, op, num1, num2;

    cout << "Selecione uma operação";
    cout << "1. soma";
    cout << "2. subtracao";
    cout << "3. multiplicacao";
    cout << "4. divisao";
    cin >> op;

    while(op < 1 || op > 4){
        cout << "Numero invalido, digite novamene: ";
        cin >> op;
    }

    cout << "\nDigite o primeiro numero: ";
    cin >> num1;

    cout << "\nDigite o segundo numero: ";
    cin >> num2;
    
    switch (op){
        
    case 1:
        cout << resultado << soma(num1, num2);
        break;
    
    case 2:
        cout << resultado << sub(num1, num2);
        break;
    
    case 3:
        cout << resultado << mult(num1, num2);
        break;

    case 4:
        cout << (float) resultado << div(num1, num2);
        break;
    }
    

    cout << "\nResultado: " << resultado;   
}