#ifndef CALC_HPP_INCLUDED 
#define CALC_HPP_INCLUDED

int soma(int a, int b);
int sub(int a, int b);
int mult(int a, int b);
float divi(int a, int b);

#endif
