#include "calc.hpp"
#include <iostream>

using namespace std;

int main(){

    int resultado, op, num1, num2;

    cout << "Selecione uma operação";
    cout << "\n1. soma";
    cout << "\n2. subtracao";
    cout << "\n3. multiplicacao";
    cout << "\n4. divisao";
    cin >> op;

    while(op < 1 || op > 4){
        cout << "\nNumero invalido, digite novamene: ";
        cin >> op;
    }

    cout << "\nDigite o primeiro numero: ";
    cin >> num1;

    cout << "\nDigite o segundo numero: ";
    cin >> num2;
    
    switch (op){
        
    case 1:
        cout  << soma(num1, num2);
        break;
    
    case 2:
        cout << sub(num1, num2);
        break;
    
    case 3:
        cout << mult(num1, num2);
        break;

    case 4:
        cout << divi(num1, num2);
        break;
    }
    
}
