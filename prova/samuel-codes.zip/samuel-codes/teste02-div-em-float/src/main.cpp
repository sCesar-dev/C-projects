#include "calc_div.hpp"
#include <iostream>

using namespace std;

int main(){

    float num1;
    int num2;
    
    
    cout << "Digite o dividendo: ";
    cin >> num1;

    cout << "\nDigite o divisor: ";
    cin >> num2;
    
    cout << "\n" << divisao(num1, num2);

}