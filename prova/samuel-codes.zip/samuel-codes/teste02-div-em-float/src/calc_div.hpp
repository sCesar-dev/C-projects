#ifndef CALC_DIV_INCLUDED
#define CALC_DIV_INCLUDED

float divisao(float a, int b);

#endif