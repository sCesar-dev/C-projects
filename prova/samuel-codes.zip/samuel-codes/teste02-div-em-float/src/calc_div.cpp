#include "calc_div.hpp"

float divisao(float a, int b){
    return a/b;
}